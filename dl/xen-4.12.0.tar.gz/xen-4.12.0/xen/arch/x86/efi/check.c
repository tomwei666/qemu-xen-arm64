int __attribute__((__ms_abi__)) test(int i)
{
    return i;
}
